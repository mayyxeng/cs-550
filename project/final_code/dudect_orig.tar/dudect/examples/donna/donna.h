int curve25519_donna(uint8_t *mypublic, const uint8_t *secret, const uint8_t *basepoint);
