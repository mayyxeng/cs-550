#ifndef TYPES_H
#define TYPES_H

#include "crypto_uint32.h"
typedef crypto_uint32 uint32;

#include "crypto_uint64.h"
typedef crypto_uint64 uint64;

#endif
